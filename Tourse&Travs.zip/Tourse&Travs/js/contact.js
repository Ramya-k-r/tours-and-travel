document.addEventListener("DOMContentLoaded", function () {
    const contactForm = document.querySelector("form");

    contactForm.addEventListener("submit", async function (event) {
        event.preventDefault(); // Prevent page refresh

        // Collect form data
        let formData = {
            name: document.getElementById("name").value.trim(),
            email: document.getElementById("email").value.trim(),
            message: document.getElementById("message").value.trim(),
        };

        // Validate form data (basic validation)
        if (!formData.name || !formData.email || !formData.message) {
            alert("Please fill in all fields before submitting.");
            return;
        }

        try {
            let response = await fetch("http://localhost:8214/tours_travel/contacts", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData),
            });

            if (response.ok) {
                alert("Message sent successfully!");
                contactForm.reset(); // Clear the form
            } else {
                let result = await response.json();
                alert("Error: " + (result.message || "Failed to send message."));
            }
        } catch (error) {
            console.error("Error:", error);
            alert("Failed to send message. Please try again.");
        }
    });
});
