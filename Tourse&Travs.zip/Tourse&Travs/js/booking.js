document.addEventListener("DOMContentLoaded", function () {
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
    const userEmail = localStorage.getItem("useremail");

    if (!isLoggedIn || !userEmail) {
        alert("You need to log in first to book a tour!");
        window.location.href = "login.html";
        return;
    }

    const destinationSelect = document.getElementById("destination");
    const personsInput = document.getElementById("persons");
    const priceInput = document.getElementById("price");
    const bookingForm = document.getElementById("booking-form");

    function updatePrice() {
        const selectedOption = destinationSelect.options[destinationSelect.selectedIndex];
        const basePrice = parseInt(selectedOption.getAttribute("data-price")) || 0;
        const numberOfPersons = parseInt(personsInput.value) || 1;

        if (basePrice > 0) {
            const totalPrice = basePrice * numberOfPersons;
            priceInput.value = `₹${totalPrice.toLocaleString()}`;
            priceInput.setAttribute("data-raw-price", totalPrice);
        } else {
            priceInput.value = "";
            priceInput.setAttribute("data-raw-price", "0");
        }
    }

    destinationSelect.addEventListener("change", updatePrice);
    personsInput.addEventListener("input", updatePrice);

    bookingForm.addEventListener("submit", async function (event) {
        event.preventDefault();

        const bookingData = {
            email: userEmail, // Ensure email is included
            name: document.getElementById("name").value, // Fixed name field
            destination: destinationSelect.value,
            mobile: document.getElementById("mobile").value,
            travelDate: document.getElementById("date").value,
            persons: parseInt(personsInput.value),
            price: parseFloat(priceInput.getAttribute("data-raw-price")) || 0, // Fixed key name
        };

        try {
            const response = await fetch("http://localhost:8214/tours_travel/bookings/new", { 
                method: "POST",
                headers: { 
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify(bookingData),
            });

            if (!response.ok) {
                throw new Error("Booking failed. Please try again.");
            }

            alert("Booking confirmed! Thank you for booking we will contact you in short notice .");
            window.location.href = "index.html";
        } catch (error) {
            console.error("Booking Error:", error);
            alert("Something went wrong. Try again.");
        }
    });
});
