console.log("JavaScript Loaded Successfully!");

document.addEventListener("DOMContentLoaded", function () {
    const API_BASE_URL = "http://localhost:8214/tours_travel"; 

    const loginForm = document.getElementById("login-form");
    const signupForm = document.getElementById("signup-form");
    const otpLoginForm = document.getElementById("otp-login-form");
    const loginBtn = document.getElementById("loginBtn");
    const logoutBtn = document.getElementById("logoutBtn");
    const sendOtpButton = document.getElementById("send-otp");
    const verifyOtpButton = document.getElementById("verify-otp");

    // 🔹 Signup Form Submission
    if (signupForm) {
        signupForm.addEventListener("submit", async function (event) {
            event.preventDefault();
            const name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
            const mobile = document.getElementById("mobile").value.trim();
            const password = document.getElementById("password").value;
            const confirmPassword = document.getElementById("confirm-password").value;

            if (password !== confirmPassword) {
                alert("Passwords do not match!");
                return;
            }

            try {
                const response = await fetch(`${API_BASE_URL}/register`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ name, email, mobile, password }),
                });

                if (!response.ok) throw new Error("Signup failed. Please try again.");
                alert("Signup successful! Please log in.");
                window.location.href = "login.html";
            } catch (error) {
                console.error("Signup Error:", error);
                alert(error.message || "Something went wrong. Try again.");
            }
        });
    }

    // 🔹 Login Form Submission
    if (loginForm) {
        loginForm.addEventListener("submit", async function (event) {
            event.preventDefault();
            const email = document.getElementById("email").value.trim();
            const password = document.getElementById("password").value;

            try {
                const response = await fetch(`${API_BASE_URL}/login`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email, password }),
                });

                if (!response.ok) throw new Error("Invalid email or password. Try again.");

                localStorage.setItem("isLoggedIn", "true");
                localStorage.setItem("useremail", email);
                alert("Login successful!");
                window.location.href = "index.html";
            } catch (error) {
                console.error("Login Error:", error);
                alert(error.message || "Invalid credentials. Try again.");
            }
        });
    }

    // 🔹 OTP Handling
    if (otpLoginForm) {
        if (sendOtpButton) {
            sendOtpButton.addEventListener("click", async function () {
                const contact = document.getElementById("contact").value.trim();
                if (!contact) {
                    alert("Enter a valid email or mobile number!");
                    return;
                }

                try {
                    const response = await fetch(`${API_BASE_URL}/send-otp`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ contact }),
                    });

                    const responseData = await response.json();
                    if (!response.ok) throw new Error(responseData.message);
                    alert(responseData.message);
                } catch (error) {
                    console.error("OTP Error:", error);
                    alert(error.message);
                }
            });
        }

        if (verifyOtpButton) {
            verifyOtpButton.addEventListener("click", async function () {
                const contact = document.getElementById("contact").value.trim();
                const otp = document.getElementById("otp").value.trim();

                if (!otp || !contact) {
                    alert("Enter both email/mobile and OTP.");
                    return;
                }

                try {
                    const response = await fetch(`${API_BASE_URL}/verify-otp`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        credentials: "include",
                        body: JSON.stringify({ contact, otp }),
                    });

                    const responseData = await response.json();
                    if (!response.ok) throw new Error(responseData.message);

                    localStorage.setItem("isLoggedIn", "true");
                    alert(responseData.message);
                    window.location.href = "index.html";
                } catch (error) {
                    console.error("OTP Verification Error:", error);
                    alert(error.message);
                }
            });
        }
    }

    // 🔹 Logout Functionality
    if (logoutBtn) {
        logoutBtn.addEventListener("click", function () {
            localStorage.removeItem("isLoggedIn");
            localStorage.removeItem("useremail");
            alert("You have been logged out.");
            window.location.href = "login.html";
        });
    }

    // 🔹 Check login status and update UI
    function updateLoginStatus() {
        if (loginBtn && logoutBtn) {
            if (localStorage.getItem("isLoggedIn") === "true") {
                loginBtn.style.display = "none";
                logoutBtn.style.display = "inline-block";
            } else {
                loginBtn.style.display = "inline-block";
                logoutBtn.style.display = "none";
            }
        }
    }

    // 🔹 Google & Facebook Login
    const googleLoginBtn = document.getElementById("google-login");
    const facebookLoginBtn = document.getElementById("facebook-login");

    if (googleLoginBtn) {
        googleLoginBtn.addEventListener("click", function () {
            window.location.href = `${API_BASE_URL}/oauth2/authorization/google`;
        });
    }

    if (facebookLoginBtn) {
        facebookLoginBtn.addEventListener("click", function () {
            window.location.href = `${API_BASE_URL}/oauth2/authorization/facebook`;
        });
    }

    // 🔹 Fetch User Details After Login
    async function fetchUser() {
        try {
            const response = await fetch(`${API_BASE_URL}/user`, { credentials: "include" });
            const userData = await response.json();
            console.log("User Data:", userData);

            if (userData.email) {
                localStorage.setItem("isLoggedIn", "true");
                localStorage.setItem("useremail", userData.email);
                alert(`Welcome ${userData.name || userData.email}`);
                window.location.href = "index.html";
            }
        } catch (error) {
            console.error("Error fetching user data:", error);
        }
    }

    updateLoginStatus();
});
