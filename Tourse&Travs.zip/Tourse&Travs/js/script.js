document.addEventListener("DOMContentLoaded", function () {
    let searchInput = document.getElementById("searchInput");
    let dropdown = document.querySelector(".search-dropdown");
    let searchContainer = document.querySelector(".search-container"); // Parent wrapper
    let searchBtn = document.getElementById("searchBtn");
    let hideTimeout;

    // Show dropdown when clicking on search input
    searchInput.addEventListener("click", function (event) {
        dropdown.style.display = "flex"; // Show dropdown
        event.stopPropagation(); // Prevent event bubbling
    });

    // Hide dropdown when clicking anywhere outside
    document.addEventListener("click", function (event) {
        if (!searchContainer.contains(event.target)) {
            dropdown.style.display = "none"; // Hide dropdown
        }
    });

    // Close dropdown when search button is clicked
    searchBtn.addEventListener("click", function () {
        let destination = document.getElementById("destination").value;
        let persons = document.getElementById("persons").value;
        let days = document.getElementById("days").value; // Changed from "amount" to "days"

        if (!destination || !persons || !days || days < 1) {
            alert("Please select all fields correctly!");
        } else {
            alert(`Searching for ${destination} with ${persons} person(s) for ${days} day(s)`);
            dropdown.style.display = "none"; // Hide dropdown after selecting
        }
    });

    // Hide dropdown if no selection is made within 3 seconds
    dropdown.addEventListener("mouseleave", function () {
        hideTimeout = setTimeout(() => {
            dropdown.style.display = "none";
        }, 3000); // Adjust timeout duration as needed
    });

    dropdown.addEventListener("mouseenter", function () {
        clearTimeout(hideTimeout); // Cancel timeout when interacting with dropdown
    });
});
document.getElementById("searchBtn").addEventListener("click", function() {
    let selectedDestination = document.getElementById("destination").value.toLowerCase();
    let tours = document.querySelectorAll(".tour");

    tours.forEach(tour => {
        let tourName = tour.querySelector("p strong").innerText.toLowerCase();
        let tourCategory = tour.getAttribute("data-category");

        if (selectedDestination === "" || tourName.includes(selectedDestination)) {
            tour.style.display = "block"; // Show matched tour
        } else {
            tour.style.display = "none"; // Hide unmatched tour
        }
    });
});
document.getElementById("searchBtn").addEventListener("click", function () {
    let selectedDestination = document.getElementById("destination").value.toLowerCase();
    let selectedBudget = document.getElementById("budget").value; // Get selected budget range
    let tours = document.querySelectorAll(".tour");

    tours.forEach(tour => {
        let tourName = tour.querySelector("p strong").innerText.toLowerCase();
        let tourBudget = parseInt(tour.getAttribute("data-budget")); // Get tour budget as an integer

        let budgetRange = selectedBudget.split("-"); // Split the selected budget range
        let minBudget = parseInt(budgetRange[0]);
        let maxBudget = budgetRange[1] ? parseInt(budgetRange[1]) : Infinity; // Handle upper limit

        // Check if tour matches either destination or budget
        let matchesDestination = selectedDestination === "" || tourName.includes(selectedDestination);
        let matchesBudget = selectedBudget === "" || (tourBudget >= minBudget && tourBudget <= maxBudget);

        if (matchesDestination && matchesBudget) {
            tour.style.display = "block"; // Show matched tour
        } else {
            tour.style.display = "none"; // Hide unmatched tour
        }
    });
});
