console.log("Forgot Password Script Loaded!");

document.addEventListener("DOMContentLoaded", function () {
    const API_BASE_URL = "http://localhost:8214/tours_travel";

    const forgotForm = document.getElementById("forgot-password-form");
    const resetForm = document.getElementById("reset-password-form");

    const sendOtpBtn = document.getElementById("send-reset-otp");
    const resetPasswordBtn = document.querySelector("#reset-password-form button");

    sendOtpBtn.addEventListener("click", async function () {
        const email = document.getElementById("forgot-email").value.trim();
        if (!email) {
            alert("Please enter your email.");
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/forgot-password/send-otp`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email }),
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || "Failed to send OTP. Try again.");
            }

            alert("OTP sent to your email.");
            forgotForm.style.display = "none";
            resetForm.style.display = "block";
        } catch (error) {
            console.error("Error sending OTP:", error);
            alert(error.message);
        }
    });

    resetPasswordBtn.addEventListener("click", async function (event) {
        event.preventDefault();

        const email = document.getElementById("forgot-email").value.trim();
        const otp = document.getElementById("reset-otp").value.trim();
        const newPassword = document.getElementById("new-password").value;
        const confirmNewPassword = document.getElementById("confirm-new-password").value;

        if (newPassword !== confirmNewPassword) {
            alert("Passwords do not match!");
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/forgot-password/reset`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, otp, newPassword }),
            });

            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || "Failed to reset password. Try again.");
            }

            alert("Password reset successfully. Please login.");
            window.location.href = "login.html";
        } catch (error) {
            console.error("Error resetting password:", error);
            alert(error.message);
        }
    });
});
